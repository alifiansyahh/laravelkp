<!DOCTYPE html>
<html lang="id">
<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pengajuan Kerja Praktik</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(to right, #00b4d8, #0077b6);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .form-wrapper {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 16px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease;
        }

        .form-wrapper h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #023e8a;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            color: #333;
            font-weight: 600;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus {
            border-color: #0077b6;
            outline: none;
        }

        button {
            background-color: #0077b6;
            color: white;
            padding: 12px;
            width: 100%;
            border: none;
            font-size: 16px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #023e8a;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>


<body>
    <div class="form-wrapper">
        <h2>Pengajuan Kerja Praktik</h2>
        <form action="<?php echo e(route('pengajuan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nama">Nama Lengkap</label>
                <input type="text" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="npm">NPM</label>
                <input type="text" id="npm"name="npm"required>
            </div>
            <div class="form-group">
                <label for="perusahaan">Perusahaan Tujuan</label>
                <input type="text" id="perusahaan" name="perusahaan" required>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat Perusahaan</label>
                <input type="text" id="alamat" name="alamat" required>
            </div>
            <div class="form-group">
                <label for="tanggal_pengajuan">tanggal pengajuan</label>
                <input type="date" id="tanggal_pengajuan" name="tanggal_pengajuan" required>
            <button type="submit">Ajukan</button>
        </form>
        
    </div>
    <?php if(session('success')): ?>
<script>
    Swal.fire({
        title: 'Berhasil!',
        text: '<?php echo e(session('success')); ?>',
        icon: 'success',
        confirmButtonText: 'OK',
        timer: 3000,
        timerProgressBar: true
    });
</script>
<?php endif; ?>

</body>
</html>
<?php /**PATH C:\laragon\www\projectKp1\resources\views/Pengajuan.blade.php ENDPATH**/ ?>