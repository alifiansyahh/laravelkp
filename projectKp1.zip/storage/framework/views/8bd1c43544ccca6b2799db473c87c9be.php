<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hasil Tracking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card p-4 shadow-sm">
        <h3 class="mb-4 text-center">Hasil Pengajuan</h3>

        <table class="table table-bordered">
            <tr>
                <th>Nama</th>
                <td><?php echo e($pengajuan->nama); ?></td>
            </tr>
            <tr>
                <th>NPM</th>
                <td><?php echo e($pengajuan->npm); ?></td>
            </tr>
            <tr>
                <th>Perusahaan</th>
                <td><?php echo e($pengajuan->perusahaan); ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td>
                    <strong class="text-<?php echo e($pengajuan->status == 'disetujui' ? 'success' : 'warning'); ?>">
                        <?php echo e(ucfirst($pengajuan->status)); ?>

                    </strong>
                </td>
            </tr>
        </table>

        <?php if($pengajuan->status == 'disetujui'): ?>
            <a href="<?php echo e(route('pengajuan.cetak', $pengajuan->id)); ?>" class="btn btn-success w-100 mt-3">Cetak Surat</a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\projectKp1\resources\views/mahasiswa/TrackingResult.blade.php ENDPATH**/ ?>