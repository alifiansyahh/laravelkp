<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard - Sistem KP</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
</head>
<body class="font-['Inter'] bg-gray-100">

  <div class="bg-blue-900 text-white text-sm px-4 py-2 flex justify-between">
    <div>
      <a href="#" class="mr-4 hover:underline">Facebook</a>
      <a href="#" class="mr-4 hover:underline">Twitter</a>
      <a href="#" class="hover:underline">Instagram</a>
    </div>
    <div>📞 +6282121380866</div>
  </div>

  <header class="bg-white shadow-md py-4 px-6 flex justify-between items-center">
    <div class="text-2xl font-extrabold text-blue-800">USB<span class="text-cyan-500">YPKP</span></div>
    <nav>
      <ul class="flex space-x-6 font-semibold text-gray-700">
        <li><a href="<?php echo e(route('login')); ?>" class="hover:text-blue-600">Login</a></li>
        <li class="relative group">
          <a href="#" class="hover:text-blue-600">Tracking ▾</a>
          <ul class="absolute left-0 top-full mt-2 bg-white shadow-lg rounded hidden group-hover:block">
            <li><a href="/pengajuan" class="block px-4 py-2 hover:bg-gray-100">Pengajuan</a></li>
            <li><a href="/tracking" class="block px-4 py-2 hover:bg-gray-100">Tracking Surat</a></li>
          </ul>
        </li>
      </ul>
    </nav>
  </header>

  <section class="text-white text-center bg-blue-600 py-24 px-4 animate-fadeIn">
    <h1 class="text-4xl md:text-5xl font-extrabold mb-4">SISTEM PENGAJUAN SURAT KERJA PRAKTIK</h1>
    <p class="text-lg md:text-xl mb-6">Mulai Pengalaman Profesionalmu. Isi data, kirim, dan tunggu persetujuan.</p>
    <a href="<?php echo e(route('login')); ?>" class="bg-blue-800 hover:bg-blue-700 text-white py-3 px-6 rounded-lg text-lg font-semibold transition">Login Sekarang</a>
  </section>

  <div class="max-w-5xl mx-auto py-12 px-4">
    <h2 class="text-2xl font-bold text-blue-800 mb-4">Profil Website</h2>
    <p class="text-gray-700 leading-relaxed">
      Sistem ini dirancang untuk memudahkan mahasiswa dalam melakukan pengajuan surat kerja praktik secara online. Dengan tampilan yang sederhana dan fungsional, mahasiswa dapat mengajukan permohonan, memantau status pengajuan, dan mencetak surat pengantar kerja praktik secara langsung dari website ini.
    </p>
  </div>

  <div class="max-w-5xl mx-auto py-12 px-4">
    <h2 class="text-2xl font-bold text-blue-800 mb-4">Alur Pengajuan Surat Kerja Praktik</h2>
    <p class="text-gray-700 mb-6">Berikut adalah tahapan proses pengajuan yang divisualisasikan dalam gambar berikut:</p>
    <div class="text-center">
      <img src="<?php echo e(asset('AlurPengajuan.png')); ?>" alt="Alur Pengajuan" class="rounded-xl shadow-lg w-full max-w-3xl mx-auto">
    </div>
  </div>

  <footer class="bg-blue-800 text-white text-center py-6 mt-12">
    <p class="text-sm">&copy; 2025 Sistem Pengajuan Surat KP - USB YPKP</p>
    <p class="text-sm">Dikembangkan oleh Mahasiswa USB YPKP</p>
  </footer>

</body>
</html>
<?php /**PATH C:\laragon\www\projectKp1\resources\views/index.blade.php ENDPATH**/ ?>